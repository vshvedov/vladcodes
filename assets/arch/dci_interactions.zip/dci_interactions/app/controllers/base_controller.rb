class BaseController < ApplicationController
  include SubAccountConcern
end
