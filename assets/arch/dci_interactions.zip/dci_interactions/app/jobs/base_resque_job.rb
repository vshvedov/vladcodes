class BaseResqueJob
  extend Resque::Plugins::History
  @queue = :base_resque_job
end
