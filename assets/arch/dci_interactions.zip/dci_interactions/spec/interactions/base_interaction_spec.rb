require 'spec_helper'

describe BaseInteraction do
end

